import cycling.*;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;

/**
 * A short program to illustrate an app testing some minimal functionality of a
 * concrete implementation of the CyclingPortal interface -- note you
 * will want to increase these checks, and run it on your CyclingPortalImpl class
 * (not the BadCyclingPortal class).
 *
 * 
 * @author Diogo Pacheco
 * @version 2.0
 */
public class CyclingPortalTestApp {

	/**
	 * Test method.
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) throws InvalidNameException, IllegalNameException, IDNotRecognisedException {
		System.out.println("The system compiled and started the execution...");

		// TODO replace BadMiniCyclingPortalImpl with CyclingPortalImpl
		MiniCyclingPortal portal1 = new CyclingPortalImpl();
		MiniCyclingPortal portal2 = new CyclingPortalImpl();

        assert (portal1.getRaceIds().length == 0)
				: "Initial Portal not empty as required or not returning an empty array.";
		assert (portal1.getTeams().length == 0)
				: "Initial Portal not empty as required or not returning an empty array.";


        assert (portal1.getTeams().length == 1)
				: "Portal1 should have one team.";

		assert (portal2.getTeams().length == 1)
				: "Portal2 should have one team.";

		try {
			// Test createRace
			int raceId = portal1.createRace("Tour de France", "The most famous cycling race");
			System.out.println("Race created with ID: " + raceId);

			// Test createStage
			int stageId = portal1.addStageToRace(raceId, "Stage 1", "First stage of the race", 150.0,
					LocalDateTime.now(), StageType.MEDIUM_MOUNTAIN);
			System.out.println("Stage created with ID: " + stageId);

			// Test createTeam
			int teamId = portal1.createTeam("Team Sky", "A professional cycling team");
			System.out.println("Team created with ID: " + teamId);

			// Test createRider
			int riderId = portal1.createRider(1, "Peter Sagan", 1990);
			System.out.println("Rider created with ID: " + riderId);

			// Test registerRiderResultsInStage
			LocalTime[] checkpoints = {
					LocalTime.of(8, 0, 37),  // Start checkpoint
					LocalTime.of(9, 30, 42), // Intermediate checkpoint 1
					LocalTime.of(10, 45, 7), // Intermediate checkpoint 2
					LocalTime.of(12, 0, 4) // Finish checkpoint
			};

			// Test addIntermediateSprintToStage
			int checkpoint1Id = portal1.addIntermediateSprintToStage(stageId, 50.0);
			System.out.println("Checkpoint 1 (Intermediate Sprint) created with ID: " + checkpoint1Id);

			// Test addCategorizedClimbToStage
			int checkpoint2Id = portal1.addCategorizedClimbToStage(stageId, 100.0, CheckpointType.HC, 8.0, 10.0);
			System.out.println("Checkpoint 2 (Categorized Climb) created with ID: " + checkpoint2Id);

			portal1.concludeStagePreparation(stageId);
			portal1.registerRiderResultsInStage(stageId, riderId, checkpoints);
			System.out.println("Results registered for rider in stage.");

			// Test getRiderAdjustedElapsedTimeInStage
			LocalTime elapsedTime = portal1.getRiderAdjustedElapsedTimeInStage(stageId, riderId);
			System.out.println("Elapsed time for rider in stage: " + elapsedTime);

			// Test deleteRiderResultsInStage
			portal1.deleteRiderResultsInStage(stageId, riderId);
			System.out.println("Results deleted for rider in stage.");

			// Test removeRider
			portal1.removeRider(riderId);
			System.out.println("Rider removed with ID: " + riderId);

			// Test removeStageById
			portal1.removeStageById(stageId);
			System.out.println("Stage removed with ID: " + stageId);

			// Test removeRaceById
			portal1.removeRaceById(raceId);
			System.out.println("Race removed with ID: " + raceId);

			//Make sure they're removed:
			int[] ids = portal1.getRaceIds();
			System.out.println(Arrays.toString(ids));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
